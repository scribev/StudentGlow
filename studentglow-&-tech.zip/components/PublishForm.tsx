
import React, { useState } from 'react';
import { Category, Product, BookType } from '../types';
import { generateProductCopy } from '../services/geminiService';

interface PublishFormProps {
  onPublish: (product: Product) => void;
}

export const PublishForm: React.FC<PublishFormProps> = ({ onPublish }) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: 'Skincare' as Category,
    subCategory: '',
    price: '₹',
    affiliateUrl: '',
    imageUrl: '',
    description: '',
    studentPerk: '',
    tags: ''
  });

  const handleAISuggest = async () => {
    if (!formData.name) return alert('Enter a product name first!');
    setLoading(true);
    try {
      const copy = await generateProductCopy(formData.name, formData.category, formData.subCategory);
      setFormData(prev => ({
        ...prev,
        description: `${copy.studentHook}\n\n${copy.description}`
      }));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.affiliateUrl.includes('amazon.')) {
      if (!confirm('This doesn\'t look like an Amazon link. Proceed anyway?')) return;
    }

    const newProduct: Product = {
      id: Date.now().toString(),
      ...formData,
      imageUrl: formData.imageUrl || `https://picsum.photos/seed/${formData.name}/600/400`,
      tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean)
    };
    onPublish(newProduct);
    setFormData({
      name: '',
      category: 'Skincare',
      subCategory: '',
      price: '₹',
      affiliateUrl: '',
      imageUrl: '',
      description: '',
      studentPerk: '',
      tags: ''
    });
    alert('Product Published Successfully!');
  };

  const bookSections: Exclude<BookType, 'All'>[] = ['Fiction', 'Non-Fiction', 'Textbooks', 'Reference Books'];

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-3xl p-8 border border-slate-100 shadow-xl">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-900">Add via Amazon Link</h2>
        <p className="text-slate-500">Paste your associate link below and use AI to write the description.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-700">Amazon Affiliate Link</label>
          <input 
            required
            type="url"
            placeholder="https://www.amazon.in/dp/B0..."
            className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-mono text-sm"
            value={formData.affiliateUrl}
            onChange={e => setFormData({...formData, affiliateUrl: e.target.value})}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Product Name</label>
            <input 
              required
              type="text"
              placeholder="e.g., Atomic Habits"
              className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Main Category</label>
            <select 
              className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              value={formData.category}
              onChange={e => setFormData({...formData, category: e.target.value as Category, subCategory: e.target.value === 'Books' ? 'Fiction' : ''})}
            >
              <option value="Skincare">Skincare</option>
              <option value="Gadgets">Gadgets</option>
              <option value="Books">Books</option>
            </select>
          </div>
        </div>

        {formData.category === 'Books' && (
          <div className="space-y-2 animate-in fade-in slide-in-from-top-2">
            <label className="text-sm font-semibold text-slate-700">Book Section</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {bookSections.map(type => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setFormData({...formData, subCategory: type})}
                  className={`py-2 rounded-xl border-2 transition-all font-medium text-xs ${
                    formData.subCategory === type 
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-600' 
                    : 'border-slate-100 bg-slate-50 text-slate-500 hover:border-slate-200'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Price</label>
            <input 
              required
              type="text"
              placeholder="₹499"
              className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              value={formData.price}
              onChange={e => setFormData({...formData, price: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Student Promo (optional)</label>
            <input 
              type="text"
              placeholder="e.g., Extra 10% off for Students"
              className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              value={formData.studentPerk}
              onChange={e => setFormData({...formData, studentPerk: e.target.value})}
            />
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <label className="text-sm font-semibold text-slate-700">Marketing Description</label>
            <button 
              type="button"
              onClick={handleAISuggest}
              disabled={loading}
              className="text-xs font-bold text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-lg hover:bg-indigo-100 transition-colors disabled:opacity-50"
            >
              {loading ? 'AI Writing...' : '✨ Write for Students with AI'}
            </button>
          </div>
          <textarea 
            required
            rows={4}
            placeholder="Tell students why this is a must-have..."
            className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            value={formData.description}
            onChange={e => setFormData({...formData, description: e.target.value})}
          />
        </div>

        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-700">Product Image URL (optional)</label>
          <input 
            type="url"
            placeholder="https://..."
            className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            value={formData.imageUrl}
            onChange={e => setFormData({...formData, imageUrl: e.target.value})}
          />
        </div>

        <button 
          type="submit"
          className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
        >
          Publish to Shop
        </button>
      </form>
    </div>
  );
};
